Name: Tanvi Begari
Roll Number: [2401mc09]
Set Number: 1

Question 2: Memory Statistics and Address Translation
1. Modified kalloc.c to maintain the count of free physical pages, updating it whenever a page is allocated or freed.
2. Added freepages() in the kernel and connected it through syscall.h, syscall.c, sysproc.c, user.h, and usys.S so user programs can retrieve the count.
3. Modified vm.c to add a helper that translates a virtual address using the calling process's page table and checks that the page is present and user-accessible.
4. Declared the address-translation helper in defs.h and implemented the va2pa() system-call handler in sysproc.c.
5. Updated the Makefile to include memtest.c in the user programs.
6. Added memtest.c to test free-page counts, virtual-to-physical translation, and parent-child memory behavior across fork() and wait().
