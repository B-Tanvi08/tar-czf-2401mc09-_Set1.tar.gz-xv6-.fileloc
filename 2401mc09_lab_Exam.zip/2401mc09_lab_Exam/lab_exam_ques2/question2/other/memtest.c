#include "types.h"
#include "stat.h"
#include "user.h"

int g = 42;   // global variable whose address we translate

int
main(void)
{
  int before, afterfork, afterwait, pid;

  // (i)
  printf(1, "(i)   free pages at start          : %d\n", freepages());

  // (ii)
  sbrk(10 * 4096);
  printf(1, "(ii)  free pages after sbrk(10*4096): %d\n", freepages());

  // (iii)
  printf(1, "(iii) global g: va=0x%x  pa=0x%x\n", (int)&g, va2pa((int)&g));

  // (iv)
  printf(1, "(iv)  va2pa(0x7FFFFFFF) = %d\n", va2pa(0x7FFFFFFF));

  // (v)
  before = freepages();
  pid = fork();
  if(pid < 0){
    printf(1, "fork failed\n");
    exit();
  }
  if(pid == 0){
    printf(1, "(v)   child : g va=0x%x  pa=0x%x\n", (int)&g, va2pa((int)&g));
    exit();
  }
  afterfork = freepages();   // child still holds its pages (alive or zombie)
  wait();
  afterwait = freepages();

  printf(1, "(v)   parent: g va=0x%x  pa=0x%x\n", (int)&g, va2pa((int)&g));
  printf(1, "      free pages before fork: %d\n", before);
  printf(1, "      free pages after fork : %d\n", afterfork);
  printf(1, "      free pages after wait : %d\n", afterwait);
  if(afterwait == before)
    printf(1, "      result: no memory leak\n");
  else
    printf(1, "      result: LEAK of %d pages\n", before - afterwait);
  exit();
}
